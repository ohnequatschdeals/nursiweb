
  # OQD…We

  This is a code bundle for OQD…We. The original project is available at https://www.figma.com/design/9qqDgJB2EMReithQM5nM0G/OQD%E2%80%A6We.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  