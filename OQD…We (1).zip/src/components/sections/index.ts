export { HeroSection } from './HeroSection';
export { PremiumOffersSection } from './PremiumOffersSection';
export { FeaturesSection } from './FeaturesSection';
export { BeraterSection } from './BeraterSection';
export { AngeboteSection } from './AngeboteSection';
export { DashboardSection } from './DashboardSection';